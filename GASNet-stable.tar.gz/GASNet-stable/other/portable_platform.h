/* This file is a redirect for backwards compatibility
 * New code should directly #include "gasnet_portable_platform.h"
 */
#include "gasnet_portable_platform.h"

